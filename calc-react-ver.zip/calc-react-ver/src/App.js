import React, { useState } from "react";
import "./App.css";

const App = () => {
  const [input, setInput] = useState("");

  const handleClick = (value) => {
    setInput(input + value);
  };

  const handleClear = () => {
    setInput("");
  };

  const handleCalculate = () => {
    try {
      setInput(eval(input).toString());
    } catch (error) {
      setInput("Error");
    }
  };

  const handleSquare = () => {
    try {
      setInput(Math.pow(eval(input), 2).toString());
    } catch (error) {
      setInput("Error");
    }
  };

  const handleSquareRoot = () => {
    try {
      setInput(Math.sqrt(eval(input)).toString());
    } catch (error) {
      setInput("Error");
    }
  };

  return (
    <div>
      <h3 className="text-center">CALC IT!</h3>
      <div className="container flex flex-col items-center mx-auto">
        <div className="row">
          <input
            className="input"
            id="myInput"
            type="text"
            value={input}
            readOnly
          />
        </div>
        <div className="row">
          <button className="button diffcolor" onClick={handleClear}>
            C
          </button>
          <button className="button diffcolor" onClick={() => handleClick("%")}>
            %
          </button>
          <button className="button diffcolor" onClick={handleSquare}>
            x²
          </button>
          <button className="button diffcolor" onClick={handleSquareRoot}>
            √x
          </button>
        </div>
        <div className="row">
          <button className="button" onClick={() => handleClick("7")}>
            7
          </button>
          <button className="button" onClick={() => handleClick("8")}>
            8
          </button>
          <button className="button" onClick={() => handleClick("9")}>
            9
          </button>
          <button className="button diffcolor" onClick={() => handleClick("*")}>
            *
          </button>
        </div>
        <div className="row">
          <button className="button" onClick={() => handleClick("4")}>
            4
          </button>
          <button className="button" onClick={() => handleClick("5")}>
            5
          </button>
          <button className="button" onClick={() => handleClick("6")}>
            6
          </button>
          <button className="button diffcolor" onClick={() => handleClick("/")}>
            /
          </button>
        </div>
        <div className="row">
          <button className="button" onClick={() => handleClick("1")}>
            1
          </button>
          <button className="button" onClick={() => handleClick("2")}>
            2
          </button>
          <button className="button" onClick={() => handleClick("3")}>
            3
          </button>
          <button className="button diffcolor" onClick={() => handleClick("+")}>
            +
          </button>
        </div>
        <div className="row">
          <button className="button" onClick={() => handleClick("0")}>
            0
          </button>
          <button className="button" onClick={() => handleClick(".")}>
            .
          </button>
          <button className="button diffcolor" onClick={handleCalculate}>
            =
          </button>
          <button className="button diffcolor" onClick={() => handleClick("-")}>
            -
          </button>
        </div>
      </div>
    </div>
  );
};

export default App;
